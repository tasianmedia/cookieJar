--------------------
Extra: cookieJar
--------------------
Version: 1.0.1-pl
Released: March 11, 2016
Since: April 23, 2014
Author: David Pede <dev@tasian.media> <https://twitter.com/davepede>
Copyright: (C) 2016 David Pede. All rights reserved. <dev@tasian.media>

A Cookie toolkit Extra for MODX Revolution.

Official Documentation:
http://rtfm.modx.com/extras/revo/cookiejar

GitHub Repository:
http://github.com/tasianmedia/cookiejar

Bugs & Feature Requests:
http://github.com/tasianmedia/cookiejar/issues

License:
Released under the GNU General Public License; either version 2 of the License, or (at your option) any later version.
http://www.gnu.org/licenses/gpl.html